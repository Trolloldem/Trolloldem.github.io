# Code to break repeating XOR

## Prerequisites

* [Install rust](https://www.rust-lang.org/tools/install)
* [Install rust (Windows)](https://forge.rust-lang.org/infra/other-installation-methods.html)

## How to use
Once the `cargo` utility is up and running, simply run `cargo run` in the root of this 
project.
