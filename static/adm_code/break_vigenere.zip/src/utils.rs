use std::collections::HashMap;

// Hamming Distance (bit count)
pub fn h_dist(s1b: &Vec<u8>, s2b: &Vec<u8>) -> u32 {

        // s1b.len() == s2b.len()
        let mut res :u32 = 0;
        for i in 0..s1b.len() {
                if s1b.get(i).unwrap() != s2b.get(i).unwrap() {
                        let mut mask = 0;
                        for _ in 0..8 {
                                mask = if mask == 0 { 1 } else { mask * 2 };
                                let b1 : u8 = s1b.get(i).unwrap() & mask;
                                let b2 : u8 = s2b.get(i).unwrap() & mask;
                                res = if b1 != b2 { res + 1 } else { res };
                        }
                }
        }
        return res;
}

// Scoring function to distinguish if something is English or not
pub fn get_score(s: &str) -> u32 {
        let mut scores = HashMap::new();
        scores.insert(' ', 13);
        scores.insert('e', 12);
        scores.insert('t', 11);
        scores.insert('a', 10);
        scores.insert('o', 9);
        scores.insert('i', 8);
        scores.insert('n', 7);
        scores.insert('s', 6);
        scores.insert('h', 5);
        scores.insert('r', 4);
        scores.insert('d', 3);
        scores.insert('l', 2);
        scores.insert('u', 1);
        let mut res: u32 = 0;
        let s_l = s.to_lowercase();
        for c in s_l.chars() {
                match scores.get(&c) {
                        Some(score) => res += score,
                        None => continue,
                }
        }
        return res;
}
