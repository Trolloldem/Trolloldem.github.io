mod utils;
mod xor_cipher;

use base64;
use std::fs::read_to_string;
use utils::h_dist;
use xor_cipher::{break_single, repeating_xor};

fn main() {

        let mut content = read_to_string("./b64.txt").unwrap();
        if content.ends_with("\n") {
                content.pop();
        }

        let bytes = base64::decode(content).unwrap();
        let mut trials : Vec<(f32, u8)> = Vec::new(); 

        // Guess KEYSIZE from 2 to 50
        for i in 2..51 {

                let mut b_vec = Vec::new();
                let mut j = 0;

                // Use the first 4 blocks
                for _ in 0..4 {
                        let mut b : Vec<u8> = Vec::new();
                        while b.len() < i {
                                b.push(*bytes.get(j).unwrap());
                                j += 1;
                        }
                        b_vec.push(b);
                }

                // Get Hamming Distance between all the blocks
                let mut d_vec = Vec::new();
                for ext in 0..3 {
                        for int in ext+1..4 {
                                d_vec.push((h_dist(b_vec.get(ext).unwrap(), b_vec.get(int).unwrap()) as f32) / (i as f32));
                        }
                }

                // Average the distance
                let mut m = 0.0;
                for d in &d_vec {
                        m += d;
                }
                m = m / (d_vec.len() as f32);
                trials.push((m, i as u8));
        }

        // Sort in increasing order of Hamming distance the sizes
        trials.sort_by(|a, b| a.partial_cmp(b).unwrap());

        // In this case we guessed right, so only one trials is done
        for i in 0..1 {

                // Blocks of max i bytes
                let mut blocks = Vec::new();
                let block_size = trials.get(i).unwrap().1;
                let mut idx = 0;
                while idx < bytes.len() {
                        let mut c_block = Vec::new();
                        while c_block.len() < block_size as usize  && idx < bytes.len(){
                                c_block.push(*bytes.get(idx).unwrap());
                                idx += 1;
                        }
                        blocks.push(c_block);
                }
                
                // ith block contains ith bytes of each block of size i
                let mut pos_blocks = Vec::new();
                for _ in 0..block_size {
                        pos_blocks.push(Vec::new());
                }

                for idx in 0..block_size {
                       let to_fill = pos_blocks.get_mut(idx as usize).unwrap();
                       for block in &blocks {
                                if (idx as usize) < block.len() {
                                        to_fill.push(block.get(idx as usize).unwrap());
                                }
                        }
                }

                // break each block as a single byte XOR cipher and store the retrieved key
                let mut key_b = Vec::new();
                for p_b in pos_blocks{
                        let res = break_single(&p_b);
                        key_b.push(res.1);
                }

                // use all the keyes to obtain the final plaintext
                let res_b = repeating_xor(&bytes, &key_b);
                match std::str::from_utf8(&res_b) {
                        Ok(string) => {
                                println!("Plaintext:\n{}", string);
                                println!("Key: {}", std::str::from_utf8(&key_b).unwrap())
                        },
                        Err(_) => continue,
                };

        }
}
