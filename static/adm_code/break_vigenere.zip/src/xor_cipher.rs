use crate::utils::get_score;

pub fn break_single(s: &Vec<&u8>) -> (String, u8, u32) {
    let mut res = String::from("");
    let mut max_score :u32 = 0;
    let mut key :u8 = 0;
    for i in 0..255 {
        let mut c : Vec<u8> = Vec::new();
        c.push(i as u8);
        let c_res_b = single_xor(s, c);
        match std::str::from_utf8(&c_res_b) {
                Ok(string) => {
                        let c_score = get_score(string);
                         if max_score < c_score {
                                res = String::from(string);
                                max_score = c_score;
                                key = i;
                         }
                },
                Err(_) => continue,
        };
    }
    return (res, key, max_score);
}



pub fn repeating_xor(s1b: &Vec<u8>, s2b: &Vec<u8>) -> Vec<u8>{

        let mut res: Vec<u8> = Vec::new();
        let mut i = 0;
        while i < s1b.len() {
                res.push(s1b.get(i).unwrap() ^ s2b.get(i % s2b.len()).unwrap());
                i += 1;
        }
        return res;
}


pub fn single_xor(s1b: &Vec<&u8>, s2b: Vec<u8>) -> Vec<u8>{

        let mut res: Vec<u8> = Vec::new();
        let mut i = 0;

        while i < s1b.len() {
                res.push(*s1b.get(i).unwrap() ^ s2b.get(0).unwrap());
                i += 1;
        }
        return res;
}
