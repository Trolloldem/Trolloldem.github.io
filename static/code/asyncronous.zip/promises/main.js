function loadUsers() {
    return fetch("data/users.json").then(response => {
        return response.json();
    })
}

document.addEventListener("DOMContentLoaded", () => {
    loadUsers().then(users => {
        console.log(users);
    }).catch(err => {
        console.error(err);
    });
});
