function loadUsers() {
    let xhr = new XMLHttpRequest();
    xhr.open("GET", "data/users.json");
    xhr.responseType = "json";
    xhr.onload = () => {
        if (xhr.status != 200) {
            console.error("ERROR AT THE APPLICATION LEVEL")
            return
        }
        console.log(xhr.response)
    }
    xhr.onerror = () => {
        console.error("ERROR AT THE NETWORK LEVEL")
    }
    xhr.send();
}

document.addEventListener("DOMContentLoaded", () => {
    loadUsers();
});
