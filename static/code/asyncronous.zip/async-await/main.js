async function loadUsers() {
    let users = null
    try {
        const response = await fetch("data/users.json");
        users = await response.json();
    } catch (e) {
        console.log(e);
    }

    return users;
}

document.addEventListener("DOMContentLoaded", async () => {
    let users = await loadUsers();
    console.log(users)
});
