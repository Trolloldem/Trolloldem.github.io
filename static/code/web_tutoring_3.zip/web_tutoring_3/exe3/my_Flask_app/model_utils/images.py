import os
import random
from sqlite3 import IntegrityError
from app import db


# Class representing images
class Image(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(500), unique=True)
    ext = db.Column(db.String(5))
    user = db.relationship('User', lazy=True, backref='user', uselist=False)

    def __init__(self, image_id, filename, extension):
        from app import hashing
        self.id = image_id
        self.name = "{}.{}".format(hashing.hash_value(value=filename), extension)
        self.ext = extension


# Add an image to the database
def add_image(file):
    from app import app
    filename = file.filename
    image_id = Image.query.count()
    added = False
    # Since the hashed name is based on the hash of the original name
    # We have to avoid that 2 images with the same name produces the same hash
    random_added = ""
    while not(added):
        try:
            db.session.add(Image(image_id, filename + str(random.random()), filename.split(".")[-1].lower()))
            db.session.commit()
            added = True
        # If the hash causes a violation of the primary key constraint generate a random number and append it to
        # the original name of the image
        except IntegrityError:
            random_added = str(random.random())
    fresh = get_image_by_id(image_id)
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], fresh.name))
    return fresh.name


# Recover images based on their id field
def get_image_by_id(image_id):
    return Image.query.filter_by(id=image_id).first()


def _gen_images():
    img_names = ("1998c5dde82dc4d68cd44ab36e5e2d87fac608b790ed9e415b88665b4f313247.jpg",
                 "e297571248fb21af611f3495562abf6301f2e06fa60ccc826e4b93711d6d5dab.jpg",
                 "ff512512424288c92641c26a0b3024cc370e11d036b90d4612f2f5f4e3cba06d.jpg",
                 "ab65615a8176bdd8f0a1b2fc7885ea542a4463fc0d13214c4d40fa58895e5377.jpg")
    for name, img_id in zip(img_names, range(0, 4)):
        to_add = Image(img_id, "", "jpg")
        to_add.name = name
        db.session.add(to_add)
        db.session.commit()
