function get_delete_url(userid){
    return `${window.location.protocol}//${window.location.host}/delete/${userid}`
}
function delete_user(userid){
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", get_delete_url(userid), false ); // false for synchronous request
    xmlHttp.send( null );
    window.location.replace(xmlHttp.responseURL);
}