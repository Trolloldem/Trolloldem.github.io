import jsonpickle
from app import db


# Generate fake database
def _placeholder_gen():

    names = ("Dario", "Gianluca", "Matthew", "Stefano")
    surnames = ("Facchinetti", "Oldani", "Rossi", "Paraboschi")
    emails = ("dario.facchinetti@unibg.it", "gianluca.oldani@unibg.it", "matthew.rossi@unibg.it", "parabosc@unibg.it")
    professions = ("PhD Student", "PhD Student", "Phd Student", "Full Professor")
    img_names = ("1998c5dde82dc4d68cd44ab36e5e2d87fac608b790ed9e415b88665b4f313247.jpg",
                 "e297571248fb21af611f3495562abf6301f2e06fa60ccc826e4b93711d6d5dab.jpg",
                 "ff512512424288c92641c26a0b3024cc370e11d036b90d4612f2f5f4e3cba06d.jpg",
                 "ab65615a8176bdd8f0a1b2fc7885ea542a4463fc0d13214c4d40fa58895e5377.jpg")
    all_info = (
            '''Dario Facchinetti is a Ph.D. student at Università degli Studi di Bergamo since October 2018. 
            He likes to spend time inside the Emacs ecosystem, programming and learning about security.''',
            '''Gianluca Oldani is a PhD student at Università degli Studi di Bergamo since October 2020. 
                        The main focuses of his work are distributed/decentralized system, policy management and privacy in data 
                        market scenarios. He enjoys experimenting various web frameworks and solving competitive programming 
                        problems. His non-work interests are videogames and role-playing games.
                        '''
            ,
                '''Matthew Rossi is a PhD student at Università degli Studi di Bergamo. 
                His work focuses on mobile systems security, policy management and privacy in data market scenarios. 
                He loves to solve problems and engage with projects that require him to learn new things.''',
            '''
            Focus on several areas in computer science: information systems and database technology 
            (specifically on active rules, view management, data warehouses, workflow management systems), 
            Web technology (data intensive Web sites, XML) and information security 
            (security for databases, access control for XML and Web services, secure reputation in P2P networks,
             data outsourcing, privacy).
            '''
                )
    ids = range(0, 4)
    # INSERT INTO the database the starting users
    for userid, name, surname, email, profession, info, img in zip(ids, names, surnames, emails, professions, all_info, img_names):
        db.session.add(User(userid, name, surname, email, profession, info, img))
        db.session.commit()


# Class representing users
class User(db.Model):
    # Relation definition
    id = db.Column(db.Integer, unique=True, primary_key=True)
    name = db.Column(db.Text(), unique=True, nullable=False)
    surname = db.Column(db.Text(), nullable=False)
    email = db.Column(db.Text(), nullable=False)
    profession = db.Column(db.Text(), nullable=False)
    info = db.Column(db.Text(), nullable=False)
    # Child foreign key
    img = db.Column(db.Text(), db.ForeignKey("image.name"), primary_key=True)
    # Father of foreign key (uselist = False is a one-to-one, uselist = True is a one-to-may)
    password = db.relationship("Password", backref="user", cascade="all,delete",lazy=False, uselist=False)

    def __init__(self, userid, name, surname, email, profession, info, img):
        self.id = userid
        self.name = name
        self.surname = surname
        self.email = email
        self.profession = profession
        self.info = info
        self.img = img


    # to_string
    def __repr__(self):
        return "User-{}: {} - {}".format(self.id, self.get_full_name(), self.password)

    # Method to get the user full name
    def get_full_name(self):
        return "{name} {surname}".format(surname=self.surname, name=self.name)

    # Method to convert a user in JSON format to store it in session["user"]
    def to_json(self):
        return jsonpickle.encode(self)

    # Avoid to have useless or risky attribute when converting to JSON
    def __getstate__(self):
        state = self.__dict__.copy()
        del state['password']
        del state["_sa_instance_state"]
        return state

    # Avoid to have useless or risky attribute when converting to JSON
    def __setstate__(self, state):
        self.__dict__.update(state)


# Create a User object from its json representation in session["user"]
def get_user_from_json(json):
    return jsonpickle.decode(json)


# Recover all users in the database
def get_users():
    return {user.id:user for user in User.query.all()}


# Recover a user by its username
def get_user_by_name(name):
    return User.query.filter_by(name=name).first()


# Modify a user already in the database
def modify_user_by_name(name, new_user, img_name):
    user = get_user_by_name(name)
    user.name = new_user.get("name", "") if new_user.get("name", "") != "" else user.name
    user.surname = new_user.get("surname", "") if new_user.get("surname", "") != "" else user.surname
    user.email = new_user.get("mail", "") if new_user.get("mail", "") != "" else user.email
    user.profession = new_user.get("occupation", "") if new_user.get("occupation", "") != "" else user.profession
    user.info = new_user.get("info", "") if new_user.get("info", "") != "" else user.info
    user.img = img_name if img_name else user.img
    db.session.commit()


# Add a new user to the database
def add_user(new_user, img_name):
    userid = User.query.count()
    name = new_user.get("name", "")
    surname = new_user.get("surname", "")
    email = new_user.get("mail", "")
    profession = new_user.get("occupation", "")
    info = new_user.get("info", "")
    img = img_name if img_name else "ff512512424288c92641c26a0b3024cc370e11d036b90d4612f2f5f4e3cba06d.jpg"
    db.session.add(User(userid, name, surname, email, profession, info, img))
    db.session.commit()


# Delete a user in the database
def delete_user_by_id(userid):
    to_delete = User.query.filter(User.id == userid).one_or_none()
    if to_delete:
        db.session.delete(to_delete)
        db.session.commit()
