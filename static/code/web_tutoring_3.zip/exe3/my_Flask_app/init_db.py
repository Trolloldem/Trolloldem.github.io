from app import db
from model_utils.user import User, _placeholder_gen
from model_utils.password_handler import Password, _gen_placeholder_passwords
from model_utils.images import Image, _gen_images

# Generate the db and insert all the starting users
db.drop_all()
db.create_all()
db.session.commit()
_gen_images()
_placeholder_gen()
_gen_placeholder_passwords()
users = User.query.all()
passwords = Password.query.all()
images = Image.query.all()
for u in users:
    print(u, u.img)
print("=======")
for i in images:
    print(i.user)
