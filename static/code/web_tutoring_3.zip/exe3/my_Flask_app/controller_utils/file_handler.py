from model_utils.images import add_image

# Store in a tuple all the accepted image extensions
_ALLOWED_EXTENSIONS = ("jpg", "jpeg", "png")


# Check the file extension
def _check_extension(filename):
    # The string.split("char") function divides a string in a list based on the char, string.split() divides on spaces
    # variable in list checks if the variable is present in the list
    return filename.split(".")[-1].lower() in _ALLOWED_EXTENSIONS


# Do every check on the uploaded image and request
def check_request(request):
    # Check if the image is present in the request
    if 'file' not in request.files:
        return False
    # Check if the image has a name
    file = request.files['file']
    if file.filename == "":
        return False

    # Check that the file extension is allowed and return the result
    return _check_extension(file.filename)


def store_image(request):
    return add_image(request.files['file'])