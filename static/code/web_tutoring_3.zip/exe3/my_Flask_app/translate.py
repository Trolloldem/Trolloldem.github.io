from sqlalchemy.orm import aliased

from app import db
from datetime import date
from sqlalchemy import func, text, cast, desc, bindparam


# all the queries discussed during lesson
class Studente(db.Model):
    __tablename__ = "STUDENTE"
    Matr = db.Column(db.Text, primary_key=True)
    Nome = db.Column(db.Text)
    DataNascita = db.Column(db.Date)
    Citta = db.Column(db.Text)

    def __init__(self, Matr, Nome, DataNascita, Citta):
        self.Matr = Matr
        self.Nome = Nome
        self.DataNascita = DataNascita
        self.Citta = Citta


class Corso(db.Model):
    __tablename__ = "CORSO"
    Codice = db.Column(db.Text, primary_key=True)
    Titolo = db.Column(db.Text)
    CFU = db.Column(db.Integer)
    Docente = db.Column(db.Text)

    def __init__(self, Codice, Titolo, CFU, Docente):
        self.Codice = Codice
        self.Titolo = Titolo
        self.CFU = CFU
        self.Docente = Docente


class Pianostudi(db.Model):
    __tablename__ = "PIANOSTUDI"
    MatrStud = db.Column(db.Text, db.ForeignKey("STUDENTE.Matr"),primary_key=True)
    CodCorso = db.Column(db.Text, db.ForeignKey("CORSO.Codice"),primary_key=True)
    Anno = db.Column(db.Integer)

    def __init__(self, Matr, Codice, Anno):
        self.MatrStud = Matr
        self.CodCorso = Codice
        self.Anno = Anno

class Esame(db.Model):
    __tablename__ = "ESAME"
    MatrStud = db.Column(db.Text, db.ForeignKey("STUDENTE.Matr"),primary_key=True)
    CodCorso = db.Column(db.Text, db.ForeignKey("CORSO.Codice"),primary_key=True)
    Data = db.Column(db.Date)
    Voto = db.Column(db.Integer)
    NroProgr = db.Column(db.Integer)
    __table_args__ = (db.ForeignKeyConstraint([MatrStud, CodCorso], [Pianostudi.MatrStud, Pianostudi.CodCorso]), {})

    def __init__(self, MatrStud, CodCorso, Data, Voto):
        self.MatrStud = MatrStud
        self.CodCorso = CodCorso
        self.Data = Data
        self.Voto = Voto

db.drop_all()
db.create_all()
db.session.commit()
Studenti = [Studente("1040358", "Gianluca", date.fromisoformat("1996-05-19"), "Brescia"),
Studente("1040359", "Mario", date.fromisoformat("1996-06-18"), "Brescia"),
Studente("1040360", "Teresa", date.fromisoformat("1996-08-15"), "Bergamo")]

Corsi = [Corso("38003", "BdWeb", 35, "Stefano Paraboschi"),
Corso("39004", "SMS", 30, "Alessandro Fassò"),
Corso("38004", "FDE", 20, "Valerio Re")]

Piani = [Pianostudi("1040358","38003",2),
Pianostudi("1040359","38003",2),
Pianostudi("1040360", "38003",2),
Pianostudi("1040358","38004",2),
Pianostudi("1040359","38004",2),
Pianostudi("1040360", "38004",2),
Pianostudi("1040358","39004",2),
Pianostudi("1040359","39004",2),
Pianostudi("1040360", "39004",2)]

Esami = [Esame("1040358", "38003", date.fromisoformat("2021-01-23"), 30),
Esame("1040358", "38004", date.fromisoformat("2021-01-24"), 27),
Esame("1040358", "39004", date.fromisoformat("2021-01-30"), 28),
Esame("1040359", "38003", date.fromisoformat("2021-01-23"), 25),
Esame("1040360", "38003", date.fromisoformat("2021-01-23"), 18),
Esame("1040360", "39004", date.fromisoformat("2021-01-24"), 20)]


db.session.bulk_save_objects(Studenti)
db.session.bulk_save_objects(Corsi)
db.session.bulk_save_objects(Piani)
db.session.bulk_save_objects(Esami)

db.session.commit()

"""SELECT STUDENTE.Matr, SUM(CAST(Corso.CFU * ESAME.Voto AS float))/SUM(CAST(Corso.CFU AS float)) AS MEDIA FROM
STUDENTE JOIN ESAME on STUDENTE.Matr = ESAME.MatrStud
JOIN CORSO on Corso.Codice = ESAME.CodCorso
GROUP BY STUDENTE.Matr
HAVING SUM(Corso.CFU) > 60
ORDER BY SUM(Corso.CFU * ESAME.Voto)/SUM(Corso.CFU) DESC;"""

to_order = cast(func.sum(Corso.CFU * Esame.Voto), db.Float)/ cast(func.sum(Corso.CFU), db.Float)
results = (db.session.query(Studente.Matr, to_order)
            .select_from(Studente)
           .join(Esame).join(Corso)
           .group_by(Studente.Matr)
           .having(func.sum(Corso.CFU) > 60)
           .order_by(desc(to_order)))\
    .all()

print(results)

print(db.session.execute(text("""SELECT STUDENTE.Matr, SUM(CAST(Corso.CFU * ESAME.Voto AS float))/SUM(CAST(Corso.CFU AS float)) AS MEDIA FROM
STUDENTE JOIN ESAME on STUDENTE.Matr = ESAME.MatrStud
JOIN CORSO on Corso.Codice = ESAME.CodCorso
GROUP BY STUDENTE.Matr
HAVING SUM(Corso.CFU) > 60
ORDER BY SUM(Corso.CFU * ESAME.Voto)/SUM(Corso.CFU) DESC;""")).all())

"""
SELECT STUDENTE.Nome FROM
STUDENTE JOIN ESAME on STUDENTE.Matr = ESAME.MatrStud JOIN
PIANOSTUDI on ESAME.CodCorso = PIANOSTUDI.CodCorso and ESAME.MatrStud = PIANOSTUDI.MatrStud
GROUP BY STUDENTE.Matr
HAVING count(*) = (SELECT count(*) FROM STUDENTE AS S JOIN PIANOSTUDI as P on S.Matr=P.MatrStud
WHERE S.Matr=STUDENTE.Matr);
"""

alias_stud = aliased(Studente)
alias_piano = aliased(Pianostudi)
sub = db.session.query(func.count())\
    .select_from(alias_stud).join(alias_piano)\
    .filter(alias_stud.Matr == Studente.Matr)\
    .scalar_subquery()

all_passed = db.session.query(Studente.Nome).select_from(Studente)\
    .join(Esame).join(Pianostudi)\
    .group_by(Studente.Matr)\
    .having(func.count() == sub).all()

print(all_passed)
"""
UPDATE ESAME
SET NroProgr = (SELECT count(*) FROM ESAME AS E
WHERE E.DATA < ESAME.DATA AND E.MatrStud = ESAME.MatrStud);
UPDATE "ESAME" 
SET "NroProgr"=(SELECT count(*) AS count_1 FROM "ESAME" AS "ESAME_1" 
WHERE "ESAME_1"."Data" < "ESAME"."Data" AND "ESAME_1"."MatrStud" = "ESAME"."MatrStud
"""
alias_exam = aliased(Esame)
selection = db.session.query(func.count()).select_from(alias_exam)\
    .filter(alias_exam.Data < Esame.Data)\
    .filter(alias_exam.MatrStud == Esame.MatrStud).scalar_subquery()
db.session.query(Esame).update({Esame.NroProgr: selection})
for e in Esame.query.all():
    e.NroProgr = e.NroProgr + 1
db.session.commit()
for e in Esame.query.all():
    print(e.NroProgr, e.MatrStud)

# Usage of prepared statement
print(db.session.execute(text("""SELECT STUDENTE.Nome FROM STUDENTE WHERE STUDENTE.Matr = :matr"""), {"matr":"1040358"}).all())
print(db.session.execute(Studente.query.filter(Studente.Matr == bindparam("matr")), {"matr":"1040358"}).all())
matr = "1040358"
print(db.session.execute(Studente.query.filter(Studente.Matr == matr)).all())