class Entry:
    def __init__(self, last_access, result):
        self.last_access = last_access
        self.result = result

# Insert something that is not a number to end the loop
if __name__ == "__main__":
    values = []
    while value := input("Inserisci un numero: "):
        try:
            values.append(float(value))
        except:
            break
    
    cache = {}
    for i, value in enumerate(values):
        print("Request =", value)
        if value not in cache:
            # Remove least recently used element in the cache when full
            if len(cache) == 10:
                oldest = float("+inf")
                target_key = None
                for key, entry in cache.items():
                    if entry.last_access < oldest:
                        oldest = entry.last_access
                        target_key = key
                print("Remove", target_key)
                del cache[target_key]
            # Add element to the cache
            print("Add", value)
            cache[value] = Entry(i, value**2)
        else:
            # Update info about the latest access
            cache[value].last_access = i
        print("Result =", cache[value].result)
