# Pages that can be accessed without being logged
_allowed = {"favicon.ico", "style.css", "landing"}


# Check if the request page can be accessed without being logged
def check_allowed(path):
    parts = path.split("/")
    # The filter function produces an iterable, you can use a loop like for f in filter():
    # Or you can use the next(filert(), default_value) if you know that the filter() gives you at most one element
    return next(filter(lambda part: part in _allowed, parts), False)
