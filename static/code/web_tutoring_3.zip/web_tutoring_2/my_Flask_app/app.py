from flask import Flask, render_template, request, session, redirect, url_for, send_from_directory
from model_utils.user import get_user_by_name, get_users, modify_user_by_name, add_user, get_user_from_json
from controller_utils.file_handler import check_request, store_image
from controller_utils.paths import check_allowed
from flask_bcrypt import Bcrypt  # flask.ext no longer exists
from flask_hashing import Hashing
from flask_resize import Resize
import os

# Initialize the Flask application
app = Flask(__name__)

# Get the root of the application (in this way we can run the app from outside the my_Flask_app folder)
root = app.root_path

# This configuration is necessary to use Flask sessions (they are signed with this secret)
app.secret_key = "Very Strong Password"

# Configure the upload folder
app.config["UPLOAD_FOLDER"] = os.path.join(root, "uploads")

# Configure the resize folder
app.config["RESIZE_URL"] = "/avatars"
app.config["RESIZE_ROOT"] = os.path.join(root, "uploads")

# Start utils to crypt password
bcrypt = Bcrypt(app)

# Start utils to hash image names
hashing = Hashing(app)

# Start utils to resize images
resize = Resize(app)


# The line with @ is called "annotation". In this case this code is run before every HTTTP request is processed
@app.before_request
def check_login():
    # Check if the requested page can be accessed without being logged
    if check_allowed(request.path):
        return
    # If the user is not logged redirect to the login page
    if not (session.get("user")) and request.endpoint != "login":
        return redirect(url_for("login"))


# @app.route specify the exposed URL, in this case it is "http://my_site.com/"
@app.route('/')
def login():
    # Simply render the template in templates/login/login.html
    return render_template("login/login.html")


# The page  "http://my_site.com/landing" acts differently if requested via GET or POST
@app.route('/landing', methods=["POST", "GET"])
def land():
    if request.method == "POST":
        # Recover the user by its username
        logged_user = get_user_by_name(request.form.get("username"))

        # If a user has been recovered
        if logged_user:
            # Check that the provided password its correct
            if check_password(logged_user.id, request.form.get("password")):
                # Create a Flask session for the logged user
                session["user"] = logged_user.to_json()
                return render_template("login/logged.html", user=logged_user)
        # If the login fails, redirect to the login page with an error box
        return render_template("login/login.html", error=True, name=request.form.get("username"))
    # If it's a get request use the Flask session to recover user information
    else:
        return render_template("login/logged.html", user=get_user_from_json(session["user"]))


@app.route('/collaborators')
def collaborators():
    return render_template("control/collaborators.html", users=get_users())


@app.route('/logout')
def logout():
    # Invalidate the Flask session of the user
    session.clear()
    return redirect(url_for("login"))


# The page  "http://my_site.com/landing" acts differently if request via GET or via POST
@app.route('/upload', methods=["GET", "POST"])
def upload():
    # if it's a POST request
    if request.method == "POST":
        image_name = None
        # Check that the image is actually a wanted image
        if check_request(request):
            # If it is ok, store the image on the server
            image_name = store_image(request)
        # Check what form has been compiled by the client
        if "modify" in request.form:
            modify_user_by_name(request.form["selected"], request.form, image_name)
        if "create" in request.form:
            add_user(request.form, image_name)
        return redirect(url_for("collaborators"))
    # if it's a GET request simply send the form
    else:
        return render_template("control/upload.html", users=get_users())


# In this case the get_image() function is executed for multiple routes
@app.route("/avatars/<image_name>")
@app.route("/avatars/resized-images/<image_name>")
def get_image(image_name):
    # The image_name string is directly inside the requested URL
    if "resized-images" in request.path.split("/"):
        return send_from_directory("{}/resized-images".format(app.config["RESIZE_ROOT"]), image_name)
    return send_from_directory(app.config["UPLOAD_FOLDER"], image_name)


# The app is served only if this file is run
if __name__ == '__main__':
    from model_utils.password_handler import check_password
    # Start the app on "localhost:5000"
    # The debug variable is used to automatically restart the server when code changes
    app.run(debug=True)
