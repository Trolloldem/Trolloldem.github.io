import os

# Fake database
_images = {}


# Class representing images
class Image:
    def __init__(self, image_id, filename, extension):
        from app import hashing
        self.id = image_id
        self.name = "{}.{}".format(hashing.hash_value(value=filename), extension)
        self.ext = extension


# Add an image to the database
def add_image(file):
    from app import app

    filename = file.filename
    image_id = len(_images.keys())
    _images[image_id] = Image(image_id, filename, filename.split(".")[-1].lower())
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], _images[image_id].name))
    return _images[image_id].name


# Recover images based on their id field
def get_image_by_id(image_id):
    return _images[image_id]
