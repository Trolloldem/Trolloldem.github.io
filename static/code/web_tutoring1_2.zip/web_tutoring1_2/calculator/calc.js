// Global variables to simulate the Model
screen_res = ""
first_operator = 0
second_operator = 0
last_used = 0
operation_selected = undefined

// Sum function
function sum(x,y){
  return x + y;
}

// Sum function
function sub(x,y){
  return x - y;
}

// If we click a number, we want to increment the current operator
function increment(new_num){

  // If no operation has been selected, we increment the first operator
  if (!(operation_selected)) {
    first_operator = first_operator * 10 + new_num
    new_num = first_operator
  // In the other case we increment the second operator
  }else {
    second_operator = second_operator * 10 + new_num
    new_num = second_operator
  }

  // Update the screen to change the View
  $("#screen-numbers").html(new_num)
}

// If an operation is selected, we update the Model
// Note that this function takes as argument another function (in this case the two possible input are sum() and sub())
function change_operator(operation){

  // The operation is selected only if no other operation is selected
  if (!(operation_selected)) {
    operation_selected = operation
  }
}

// If AC or = is pressed, reset the Model to its original state
// Note that this function has a default parameter: if only reset() is called, the is_ac variable will have its default value of true
function reset(is_AC=true) {
  screen_res = ""
  first_operator = 0
  second_operator = 0
  last_used = 0
  operation_selected = undefined

  // Empty the screen only if AC is pressed
  if(is_AC){
    $("#screen-numbers").html("")
  }
}

// Delete the last number on the screen if DEL is preseed
function delete_last(){

  // Same reasoning of increment: check if the operation is applied on the first or second operator
  if (!(operation_selected)){
    first_operator = Math.floor(first_operator / 10)
    new_num = first_operator
  }else {
    second_operator = Math.floor(second_operator / 10)
    new_num = second_operator
  }
  $("#screen-numbers").html(new_num)
}

// Calculate the result and update both Model and View
function calculate(){
  result = operation_selected(first_operator, second_operator)
  $("#screen-numbers").html(result)

  // Reset the Model state but not the View
  reset(false)
}

$(document).ready(function(){

  buttons = [1,2,3,"DEL",4,5,6,"AC",7,8,9,"+",0,"=","-"] // Array containing all the button values
  operations = ["DEL", "AC", "+", "=", "-"] // Array containing only the operations

  // For cycle over the entire buttons array
  buttons.forEach(function(button){

    new_div = document.createElement("div")
    new_div.setAttribute("class", "bt")

    // Larger button for 0
    if (button === 0){
      new_div.setAttribute("style", "grid-column: 1/3;")
    }

    // .some() checks if at least one operation is equal to the current element
    if (!(operations.some( element => element == button))) {
      /* if none of the operation is equal to the element
        the element is a number. We want to use the "onclick" attribute to assign
        a function that is run when the button is clicked. The function will
        be increment(element_value)
      */
      new_div.setAttribute("onclick", `increment(${button})`)
    }else{
      // If the element is an operation, we want to select the correct function to assign
      to_set = ""
      if (button === "AC"){
        to_set = "reset()"
      }
      if (button === "DEL"){
        to_set = "delete_last()"
      }
      if (button === "+"){
        to_set = "change_operator(sum)"
      }
      if (button === '-'){
        to_set = "change_operator(sub)"
      }
      if (button === '='){
        to_set = "calculate()"
      }

      new_div.setAttribute("onclick", to_set)
    }
    new_div.innerHTML = button
    $("#content").append(new_div)
  })


})
