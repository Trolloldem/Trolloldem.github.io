
// This is why we used the GET method
function extract_get_params(url_string) {

  // Use the built-in URL object to parse the URL of the page
  var url = new URL(url_string);

  // Recover the username parameter
  var username = url.searchParams.get("username") ?? ""; // The ?? operator check if the username parameter exist, if not the "" default value is used
  return username;
}

// Label and text creation
function add_label(label_str, p_string) {

  var label = document.createElement("label") // Create a new <label>
  label.setAttribute("class", "content-label") // Set the attribute class="content-label" to your new label

  /*
  The following line uses a parametrized string.
  First you define a template using ` string delimiter
  Every placeholder defined as ${variable_name} will be substituted with the actual variable value
  The same result can be obtained using string concatenation
  */
  label.innerHTML = `<strong>${label_str}</strong>` // Set <label><strong> Text </strong></label>


  var p = document.createElement("p")
  p.setAttribute("class", "content-label")
  p.innerHTML = p_string

  /*
    Packing: we want to return 2 results in the same function
    a simple way is to group the results inside an object { var1, var2}
    The object properties will have the same name of the variables used
  */
  return {label, p}
}

/* global variable */
var a = "I'm part of the Window"

/*
  jQuery selector $(document) recover the entire HTML
  with the ready() function you can wait that the enitre HTML code is rendered
  in order to avoid problems with slow clients
  the ready() function takes another function as input. In this case we
  have used an anonymous function using the
  "function() { code to run after the document is ready...}"
  definition
*/
$(document).ready(()=>{

  console.log("Document ready with anonymous function")

  /*
  This code prints the value of a only if you change
  "function()" with  "() =>"
  */
  console.log(this)
  console.log(this.a)


  username = extract_get_params(window.location.href)

  // Use the jQuery id selector
  $("#username_div").prop("class", "content-title") // .prop() is equal to .setAttribute("attribute", "value")
  $("#username_div").html(`<strong>${username}</strong>`) //.html() is equal to .innerHTML = value

  // Recover all div inside the document
  all_divs = $("div")

  // Similar to .forEach for arrays
  all_divs.each(
    function(element){
      // if you change "function(element)" with "(element) =>" this won't print the divs
      console.log(this)
    }
  )

  // Change the View
  $("#information_div").prop("class", "content-username")
  // Using var {var1, var2} automaically creates 2 variables named var1 and var2 containing the 2 results of the function
  var {label, p} = add_label("Occupation:", "INSERT HERE YOUR OCCUPATION IN THE CODE")
  $("#information_div").append(label, p)

  $("#mail_div").prop("class", "content-password")
  var {label, p} = add_label("Email-Address:", "INSERT HERE YOUR MAIL IN THE CODE")
  $("#mail_div").append(label, p)


})
