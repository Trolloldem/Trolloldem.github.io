import AbstractView from "./AbstractView.js";
import Posts from "./Posts.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.postId = params.id;
        this.setTitle("Viewing Post");
    }

    async getHtml() {
        let post = null
        try {
            const response = await fetch("/service/posts/" + this.postId);
            post = await response.json();

            // When no post matches the given id, go to list of posts
            if (!post || Object.keys(post).length === 0) {
                return new Posts().getHtml()
            }

            return `<h1>${post.title}</h1><p>${post.content}</p>`;
        } catch (e) {
            return new Posts().getHtml()
        }
    }
}
