import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Posts");
    }

    async getHtml() {
        let posts = null
        try {
            const response = await fetch("/service/posts");
            posts = await response.json();
           
            if (!posts.length)
                return `<h1>Posts</h1>
                        <p>Sorry, we could not retrieve any post.</p>`;

            let html = ""
            posts.forEach(post => {
                html += `<p><a href="/posts/${post.id}" data-link>${post.title}</a></p>`
            });
            return `
                <h1>Posts</h1>
                <p>Here is my list of posts:</p>
                ${html}
            `;
        } catch (e) {
            return `<h1>Posts</h1>
                    <p>Sorry, we could not retrieve any post.</p>`;
        }
    }
}
