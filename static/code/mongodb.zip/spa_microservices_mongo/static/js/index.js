import Home from "./views/Home.js";
import Posts from "./views/Posts.js";
import PostView from "./views/PostView.js";
import About from "./views/About.js";

// Create a regular expression from the given path
// It escapes forward slashes and substitutes params with (.+)
const pathToRegex = (path) => {
    return new RegExp(
        "^" + path.replace(/\//g, "\\/").replace(/:\w+/g, "(.+)") + "$"
    );
}

// Extract parameters values according to route and result of the previous
// matching
const getParams = match => {
    // Get keys following ':' in the route path
    const keys = Array.from(match.route.path.matchAll(/:(\w+)/g)).map(result => result[1]);
    // Get values retrieved with the previous regex matching
    const values = match.result.slice(1);

    // Create object starting from key-value pairs
    return Object.fromEntries(
        // For each key get its value and produce a key-value pair
        keys.map((key, i) => [key, values[i]])
    );
};

// Render view according to the current location
const router = async () => {
    const routes = [
        { path: "/", view: Home },
        { path: "/posts", view: Posts },
        { path: "/posts/:id", view: PostView },
        { path: "/about", view: About }
    ];

    // Test each route for potential match
    const potentialMatches = routes.map(route => {
        return {
            route: route,
            result: location.pathname.match(pathToRegex(route.path))
        };
    });

    // Get matching route 
    let match = potentialMatches.find(
        potentialMatch => potentialMatch.result !== null
    );

    // Redirect path that do not match a route to the home page
    if (!match) {
        match = {
            route: routes[0],
            result: location.pathname
        };
    }

    // Retrieve parameter
    const view = new match.route.view(getParams(match));

    // Render view in the app div
    document.querySelector("#app").innerHTML = await view.getHtml();
};

// Render view according to the change in the current path due to
// go back / go forward events
window.addEventListener("popstate", router);

document.addEventListener("DOMContentLoaded", () => {
    // Change behaviour of onclick events where there is data-link
    document.body.addEventListener("click", e => {
        if (e.target.matches("[data-link]")) {
            // Prevent default behaviour of requesting a new page
            e.preventDefault();
            // Add entry to the browser hystory
            history.pushState(null, null, e.target.href);
            // Render view according to the current location
            router();
        }
    });

    // Render view according to the current location
    router();
});
