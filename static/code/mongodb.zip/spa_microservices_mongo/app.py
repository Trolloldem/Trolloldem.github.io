import json
import os.path
import sys

from dotenv import load_dotenv
from flask import Flask
from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError


# Load .env file environment variables
load_dotenv()

# Get environment variable value
USERNAME = os.getenv("MONGODB_USERNAME")
PASSWORD = os.getenv("MONGODB_PASSWORD")
IP = os.getenv("MONGODB_IP")
PORT = os.getenv("MONGODB_PORT")

# Initialize the Flask application
app = Flask(__name__)

# Get root of the app
root = app.root_path

# Create client to MongoDB deamon
client = MongoClient(f"mongodb://{IP}:{PORT}/", serverSelectionTimeoutMS = 1000)

# Make sure connection with the MongoDB deamon has been enstablished
try:
    client.server_info()
except ServerSelectionTimeoutError:
    print("ERROR: Could not enstablish a connection to the MongoDB server")
    sys.exit()

# Retrieve posts collection
db = client.test
posts = db.posts


# Get the list of post ids and titles
@app.route('/service/posts')
def get_post_ids():
    return json.dumps(
        [{"id": post["_id"], "title": post["title"]} for post in posts.find()]
    )


# Get a post by its id
@app.route('/service/posts/<id>')
def get_post_by_id(id):
    try:
        id = int(id)
    except ValueError:
        return {}

    post = posts.find_one({"_id": id})
    return post if post is not None else {}


# Serve our single-page application
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def catch_all(path):
    return app.send_static_file("index.html")


if __name__ == '__main__':
    # Expose application at "localhost:5000"
    # debug=True configures the server to restart on code updates
    app.run(debug=True)
