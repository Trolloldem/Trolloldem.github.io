from flask import Flask

# Initialize the Flask application
app = Flask(__name__)

# Get root of the app
root = app.root_path

# Endpoint to serve our single-page application
# Every request
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def catch_all(path):
    return app.send_static_file("index.html")

if __name__ == '__main__':
    # Expose application at "localhost:5000"
    # debug=True configures the server to restart on code updates
    app.run(debug=True)
