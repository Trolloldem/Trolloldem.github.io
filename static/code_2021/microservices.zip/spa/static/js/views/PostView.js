import AbstractView from "./AbstractView.js";
import Posts from "./Posts.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.postId = params.id;
        this.setTitle("Viewing Post");
    }

    async getHtml() {
        let posts = null
        try {
            const response = await fetch("/static/data/posts.json");
            posts = await response.json();

            let match = posts.find(post => post.id == this.postId);
            return `<h1>${match.title}</h1><p>${match.content}</p>`;
        } catch (e) {
            return new Posts().getHtml()
        }
    }
}
