import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Home");
    }

    async getHtml() {
        return `
            <h1>Welcome</h1>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce
                accumsan, dui quis convallis consequat, quam nulla commodo
                velit, non mollis lectus nibh in sem. Nunc quis tellus tellus.
                Praesent dolor dolor, sodales eu pharetra ullamcorper,
                sollicitudin a justo. Quisque mattis finibus nisi sit amet
                facilisis. Etiam malesuada non felis id lacinia. Sed efficitur
                velit sit amet magna cursus, quis egestas mi consectetur.
                Quisque vehicula sapien ut mauris convallis placerat.
            </p>
            <p>
                <a href="/posts" data-link>View posts</a>
            </p>
        `;
    }
}
