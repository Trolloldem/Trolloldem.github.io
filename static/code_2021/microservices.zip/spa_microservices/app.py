import json

from flask import Flask


# Initialize the Flask application
app = Flask(__name__)

# Get root of the app
root = app.root_path


# Get the list of post ids and titles
@app.route('/service/posts')
def get_post_ids():
    with open("data/posts.json") as file:
        posts = json.load(file)

    return json.dumps(
        [{"id": post["id"], "title": post["title"]} for post in posts]
    )


# Get a post by its id
@app.route('/service/posts/<id>')
def get_post_by_id(id):
    try:
        id = int(id)
    except ValueError:
        return {}

    with open("data/posts.json") as file:
        posts = json.load(file)

    for post in posts:
        if post["id"] == id:
            return post
    return {}


# Serve our single-page application
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def catch_all(path):
    return app.send_static_file("index.html")


if __name__ == '__main__':
    # Expose application at "localhost:5000"
    # debug=True configures the server to restart on code updates
    app.run(debug=True)
