import jsonpickle

# Fake database
_all_users = {}


# Generate fake database
def _placeholder_gen():

    names = ("Dario", "Gianluca", "Matthew", "Stefano")
    surnames = ("Facchinetti", "Oldani", "Rossi", "Paraboschi")
    emails = ("dario.facchinetti@unibg.it", "gianluca.oldani@unibg.it", "matthew.rossi@unibg.it", "parabosc@unibg.it")
    professions = ("PhD Student", "PhD Student", "Phd Student", "Full Professor")
    img_names = ("1998c5dde82dc4d68cd44ab36e5e2d87fac608b790ed9e415b88665b4f313247.jpg",
                 "e297571248fb21af611f3495562abf6301f2e06fa60ccc826e4b93711d6d5dab.jpg",
                 "ff512512424288c92641c26a0b3024cc370e11d036b90d4612f2f5f4e3cba06d.jpg",
                 "ab65615a8176bdd8f0a1b2fc7885ea542a4463fc0d13214c4d40fa58895e5377.jpg")
    all_info = (
            '''Dario Facchinetti is a Ph.D. student at Università degli Studi di Bergamo since October 2018. 
            He likes to spend time inside the Emacs ecosystem, programming and learning about security.''',
            '''Gianluca Oldani is a PhD student at Università degli Studi di Bergamo since October 2020. 
                        The main focuses of his work are distributed/decentralized system, policy management and privacy in data 
                        market scenarios. He enjoys experimenting various web frameworks and solving competitive programming 
                        problems. His non-work interests are videogames and role-playing games.
                        '''
            ,
                '''Matthew Rossi is a PhD student at Università degli Studi di Bergamo. 
                His work focuses on mobile systems security, policy management and privacy in data market scenarios. 
                He loves to solve problems and engage with projects that require him to learn new things.''',
            '''
            Focus on several areas in computer science: information systems and database technology 
            (specifically on active rules, view management, data warehouses, workflow management systems), 
            Web technology (data intensive Web sites, XML) and information security 
            (security for databases, access control for XML and Web services, secure reputation in P2P networks,
             data outsourcing, privacy).
            '''
                )
    ids = range(0, 4)

    for userid, name, surname, email, profession, info, img in zip(ids, names, surnames, emails, professions, all_info, img_names):
        _all_users[userid] = User(userid, name, surname, email, profession, info, img)


# Class representing users
class User:
    def __init__(self, userid, name, surname, email, profession, info, img):
        self.id = userid
        self.name = name
        self.surname = surname
        self.email = email
        self.profession = profession
        self.info = info
        self.img = img

    # Method to get the user full name
    def get_full_name(self):
        return "{name} {surname}".format(surname=self.surname, name=self.name)

    # Method to convert a user in JSON format to store it in session["user"]
    def to_json(self):
        return jsonpickle.encode(self)


# Create a User object from its json representation in session["user"]
def get_user_from_json(json):
    return jsonpickle.decode(json)


# Recover all users in the database
def get_users():
    return _all_users


# Recover a user by its username
def get_user_by_name(name):
    all_users = get_users()
    # The filter function produces an iterable, you can use a loop like for f in filter():
    # Or you can use the next(filert(), default_value) if you know that the filter() gives you at most one element
    return next(filter(lambda user: user.name == name, all_users.values()), None)


# Modify a user already in the database
def modify_user_by_name(name, new_user, img_name):
    # dict.get(key, default_value) to avoid exceptions
    # The ternary expressions used check that a new User filed is provided, if not the old one is kept
    user = get_user_by_name(name)
    user.name = new_user.get("name", "") if new_user.get("name", "") != "" else user.name
    user.surname = new_user.get("surname", "") if new_user.get("surname", "") != "" else user.surname
    user.email = new_user.get("mail", "") if new_user.get("mail", "") != "" else user.email
    user.profession = new_user.get("occupation", "") if new_user.get("occupation", "") != "" else user.profession
    user.info = new_user.get("info", "") if new_user.get("info", "") != "" else user.info
    user.img = img_name if img_name else user.img


# Add a new user to the database
def add_user(new_user, img_name):
    # dict.get(key, default_value) to avoid exceptions
    userid = len(_all_users.keys())
    name = new_user.get("name", "")
    surname = new_user.get("surname", "")
    email = new_user.get("mail", "")
    profession = new_user.get("occupation", "")
    info = new_user.get("info", "")
    img = img_name if img_name else "ff512512424288c92641c26a0b3024cc370e11d036b90d4612f2f5f4e3cba06d.jpg"
    _all_users[userid] = User(userid, name, surname, email, profession, info, img)

# Generate fake database on module import
_placeholder_gen()
