from app import bcrypt

# Fake database
_all_pass = {}


# Generate fake database
def _gen_placeholder_passwords():
    for userid, passwd in zip(range(0, 4), ["secret", "my_pass", "tmp_pass", "bdweb2021"]):
        _all_pass[userid] = bcrypt.generate_password_hash(passwd)


# Check that the candidate password for the given userid is correct
def check_password(userid, candidate):
    return bcrypt.check_password_hash(_all_pass[userid], candidate)


# Initialize fake database when the module is imported
_gen_placeholder_passwords()
